﻿using Microsoft.Extensions.DependencyInjection;
using Spectre.Console.Cli;
using SwarmBender.Cli.Bootstrap;
using SwarmBender.Cli.Commands;

var services = new ServiceCollection()
    .AddSwarmBenderCore(Directory.GetCurrentDirectory())
    .BuildServiceProvider();

var app = new CommandApp(new TypeRegistrar(services));
app.Configure(cfg =>
{
    cfg.SetApplicationName("sb");
    cfg.AddCommand<InitCommand>("init");
    cfg.AddCommand<RenderCommand>("render");
});

return await app.RunAsync(args);