namespace SwarmBender.Core.Data.Models;

/// <summary>
/// Mutable context carried across pipeline stages.
/// </summary>
public sealed class RenderContext
{
    public required string RootPath { get; init; }
    public required string StackId  { get; init; }
    public required string Env      { get; init; }
    
    

    // Final Compose (template + overlays + stage mutations)
    public IDictionary<string, object?> Compose { get; } = new Dictionary<string, object?>();

    // Tokens (reserved/user) for later TokenExpand stage
    public IDictionary<string, string> Tokens { get; } = new Dictionary<string, string>(System.StringComparer.OrdinalIgnoreCase);

    // Collected environment variables (non-secretized)
    public IDictionary<string, string> EnvVars { get; } = new Dictionary<string, string>(System.StringComparer.OrdinalIgnoreCase);

    // Secret candidates captured during collect (flatten key -> value). Will be used by SecretsAttach stage.
    public IDictionary<string, string> SecretCandidates { get; } = new Dictionary<string, string>(System.StringComparer.OrdinalIgnoreCase);

    public List<string> Warnings { get; } = new();
}