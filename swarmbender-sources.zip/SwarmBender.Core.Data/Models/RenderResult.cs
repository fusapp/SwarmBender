namespace SwarmBender.Core.Data.Models;

public sealed record RenderResult(
    string Yaml,
    string OutFile
);