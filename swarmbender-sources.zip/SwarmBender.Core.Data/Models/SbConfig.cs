namespace SwarmBender.Core.Data.Models;

/// <summary>In-memory model of ops/sb.yml (simplified for MVP; extend as needed).</summary>
public sealed class SbConfig
{
    public string Version { get; init; } = "1";

    public RenderSection Render { get; init; } = new();
    public TokensSection Tokens { get; init; } = new();
    public SecretizeSection Secretize { get; init; } = new();
    public SecretsSection Secrets { get; init; } = new();
    public ProvidersSection Providers { get; init; } = new();

    public sealed class RenderSection
    {
        public string AppsettingsMode { get; init; } = "env";
        public string OutDir { get; init; } = "ops/state/last";
        public bool   WriteHistory { get; init; } = true;
        public List<string> OverlayOrder { get; init; } = new()
        {
            "stacks/all/{env}/stack/*.y?(a)ml",
            "stacks/{stackId}/{env}/stack/*.y?(a)ml"
        };
    }

    public sealed class TokensSection
    {
        public Dictionary<string,string> User { get; init; } = new();
        // Reserved tokens SB_STACK_ID / SB_ENV / SB_SERVICE_NAME are implicit.
    }

    public sealed class SecretizeSection
    {
        public bool Enabled { get; init; } = true;
        public List<string> Paths { get; init; } = new();
    }

    public sealed class SecretsSection
    {
        public EngineSection Engine { get; init; } = new();
        public string NameTemplate { get; init; } = "sb_{scope}_{env}_{key}_{version}";
        public string VersionMode  { get; init; } = "content-sha";
        public Dictionary<string,string> Labels { get; init; } = new();

        public sealed class EngineSection
        {
            public string Type { get; init; } = "docker-cli"; // docker-cli | docker-dotnet
            public Dictionary<string,object?> Args { get; init; } = new();
        }
    }

    public sealed class ProvidersSection
    {
        /// <summary>Order in which value sources are applied (last wins).</summary>
        public List<OrderItem> Order { get; } = new();

        public FileProvider File { get; init; } = new();
        public EnvProvider Env { get; init; } = new();
        public AzureKvProvider AzureKv { get; init; } = new();
        public InfisicalProvider Infisical { get; init; } = new();

        public sealed class OrderItem
        {
            public string Type { get; init; } = ""; // file | env | azure-kv | infisical
        }

        public sealed class FileProvider
        {
            /// <summary>Extra JSON dirs to read as KV, supports {stackId} {env} tokens.</summary>
            public List<string> ExtraJsonDirs { get; } = new();
        }

        public sealed class EnvProvider
        {
            /// <summary>JSON files that contain allowlist arrays, supports tokens.</summary>
            public List<string> AllowlistFileSearch { get; } = new();
        }

        public sealed class AzureKvProvider
        {
            /// <summary>Key Vault URI, e.g. https://myvault.vault.azure.net/</summary>
            public string? VaultUri { get; init; }

            /// <summary>When true, use DefaultAzureCredential; else use ClientSecret.</summary>
            public bool UseDefaultCredential { get; init; } = true;

            public string? TenantId { get; init; }
            public string? ClientId  { get; init; }
            public string? ClientSecret { get; init; }

            /// <summary>Optional key prefix filter, e.g. "sso/dev/". If set, only secrets starting with this prefix are considered.</summary>
            public string? KeyPrefix { get; init; }

            /// <summary>Optional map from SB env to KV subpath tokens; can be used by {env} in KeyPrefix.</summary>
            public Dictionary<string, string> EnvMap { get; } = new();
        }

        public sealed class InfisicalProvider
        {
            /// <summary>Base URL for self-hosted or default cloud.</summary>
            public string BaseUrl { get; init; } = "https://app.infisical.com";

            /// <summary>Workspace/project id or slug.</summary>
            public string? ProjectId { get; init; }
            public string? ProjectSlug { get; init; }

            /// <summary>Environment slug mapping: dev->dev, prod->prod etc.</summary>
            public Dictionary<string, string> EnvMap { get; } = new();

            /// <summary>Secret path template, e.g. "/{stackId}" or "/global".</summary>
            public string PathTemplate { get; init; } = "/";

            /// <summary>Env var name that holds the machine identity token.</summary>
            public string TokenEnvVar { get; init; } = "INFISICAL_TOKEN";

            /// <summary>Optional prefix stripping and replacements when mapping Infisical keys to flattened keys.</summary>
            public string? StripPrefix { get; init; }
            public Dictionary<string, string> Replace { get; } = new();
            public string KeyTemplate { get; init; } = "{key}";
        }
    }
}