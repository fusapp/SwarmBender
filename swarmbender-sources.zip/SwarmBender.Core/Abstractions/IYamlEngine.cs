namespace SwarmBender.Core.Abstractions;

public interface IYamlEngine
{
    IDictionary<string, object?> LoadToMap(string yamlText);
    string DumpFromMap(IDictionary<string, object?> map);
}