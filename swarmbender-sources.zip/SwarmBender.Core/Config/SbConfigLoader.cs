using SwarmBender.Core.Abstractions;
using SwarmBender.Core.Data.Models;

namespace SwarmBender.Core.Config;

public sealed class SbConfigLoader : ISbConfigLoader
{
    private readonly IYamlEngine _yaml;
    public SbConfigLoader(IYamlEngine yaml) => _yaml = yaml;

    public async Task<SbConfig> LoadAsync(string rootPath, CancellationToken ct)
    {
        var path = Path.Combine(rootPath, "ops", "sb.yml");
        var cfg = new SbConfig();

        if (!File.Exists(path))
            return cfg; // defaults

        var map = await _yaml.LoadYamlAsync(path, ct);

        // secretize.paths
        if (map.TryGetValue("secretize", out var secObj) && secObj is IDictionary<string, object?> sec)
        {
            if (sec.TryGetValue("paths", out var pathsObj) && pathsObj is IEnumerable<object?> seq)
            {
                foreach (var item in seq)
                    if (item?.ToString() is { } p && !string.IsNullOrWhiteSpace(p))
                        cfg.Secretize.Paths.Add(p);
            }
        }

        // tokens.reserved (optional, SB_* are computed; we keep for doc parity)
        if (map.TryGetValue("tokens", out var tokObj) && tokObj is IDictionary<string, object?> tok
            && tok.TryGetValue("reserved", out var resvObj) && resvObj is IEnumerable<object?> resv)
        {
            foreach (var item in resv)
                if (item?.ToString() is { } t && !string.IsNullOrWhiteSpace(t))
                    cfg.Tokens.Reserved.List.Add(t);
        }

        // providers
        if (map.TryGetValue("providers", out var provObj) && provObj is IDictionary<string, object?> prov)
        {
            // order
            if (prov.TryGetValue("order", out var ordObj) && ordObj is IEnumerable<object?> ordSeq)
            {
                foreach (var o in ordSeq)
                {
                    if (o is IDictionary<string, object?> m && m.TryGetValue("type", out var t) && t?.ToString() is { } ts && !string.IsNullOrWhiteSpace(ts))
                        cfg.Providers.Order.Add(new SbConfig.ProvidersSection.OrderItem { Type = ts });
                }
            }

            // file
            if (prov.TryGetValue("file", out var fileObj) && fileObj is IDictionary<string, object?> file)
            {
                if (file.TryGetValue("extraJsonDirs", out var dirsObj) && dirsObj is IEnumerable<object?> dirs)
                {
                    foreach (var d in dirs)
                        if (d?.ToString() is { } s && !string.IsNullOrWhiteSpace(s))
                            cfg.Providers.File.ExtraJsonDirs.Add(s);
                }
            }

            // env
            if (prov.TryGetValue("env", out var envObj) && envObj is IDictionary<string, object?> env)
            {
                if (env.TryGetValue("allowlistFileSearch", out var alObj) && alObj is IEnumerable<object?> als)
                {
                    foreach (var a in als)
                        if (a?.ToString() is { } s && !string.IsNullOrWhiteSpace(s))
                            cfg.Providers.Env.AllowlistFileSearch.Add(s);
                }
            }

            // azure-kv
            if (prov.TryGetValue("azure-kv", out var akvObj) && akvObj is IDictionary<string, object?> akv)
            {
                string S(string key) => akv.TryGetValue(key, out var v) ? (v?.ToString() ?? "") : "";

                cfg.Providers.AzureKv = new SbConfig.ProvidersSection.AzureKvProvider
                {
                    VaultUri = string.IsNullOrWhiteSpace(S("vaultUri")) ? null : S("vaultUri"),
                    UseDefaultCredential = !(akv.TryGetValue("useDefaultCredential", out var udc) && udc is bool b && b == false),
                    TenantId = string.IsNullOrWhiteSpace(S("tenantId")) ? null : S("tenantId"),
                    ClientId = string.IsNullOrWhiteSpace(S("clientId")) ? null : S("clientId"),
                    ClientSecret = string.IsNullOrWhiteSpace(S("clientSecret")) ? null : S("clientSecret"),
                    KeyPrefix = string.IsNullOrWhiteSpace(S("keyPrefix")) ? null : S("keyPrefix"),
                };

                if (akv.TryGetValue("envMap", out var em) && em is IDictionary<string, object?> emMap)
                {
                    foreach (var kv in emMap)
                        if (!string.IsNullOrWhiteSpace(kv.Key) && kv.Value?.ToString() is { } v && !string.IsNullOrWhiteSpace(v))
                            cfg.Providers.AzureKv.EnvMap[kv.Key] = v;
                }
            }

            // infisical
            if (prov.TryGetValue("infisical", out var infObj) && infObj is IDictionary<string, object?> inf)
            {
                string S(string key) => inf.TryGetValue(key, out var v) ? (v?.ToString() ?? "") : "";

                var ip = new SbConfig.ProvidersSection.InfisicalProvider
                {
                    BaseUrl = string.IsNullOrWhiteSpace(S("baseUrl")) ? "https://app.infisical.com" : S("baseUrl"),
                    ProjectId = string.IsNullOrWhiteSpace(S("projectId")) ? null : S("projectId"),
                    ProjectSlug = string.IsNullOrWhiteSpace(S("projectSlug")) ? null : S("projectSlug"),
                    PathTemplate = string.IsNullOrWhiteSpace(S("pathTemplate")) ? (S("path") ?? "/") : S("pathTemplate"),
                    TokenEnvVar = string.IsNullOrWhiteSpace(S("tokenEnvVar")) ? "INFISICAL_TOKEN" : S("tokenEnvVar"),
                    StripPrefix = string.IsNullOrWhiteSpace(S("stripPrefix")) ? null : S("stripPrefix"),
                    KeyTemplate = string.IsNullOrWhiteSpace(S("keyTemplate")) ? "{key}" : S("keyTemplate"),
                };

                if (inf.TryGetValue("envMap", out var em) && em is IDictionary<string, object?> emMap)
                    foreach (var kv in emMap)
                        if (!string.IsNullOrWhiteSpace(kv.Key) && kv.Value?.ToString() is { } v && !string.IsNullOrWhiteSpace(v))
                            ip.EnvMap[kv.Key] = v;

                if (inf.TryGetValue("replace", out var rp) && rp is IDictionary<string, object?> repMap)
                    foreach (var kv in repMap)
                        ip.Replace[kv.Key] = kv.Value?.ToString() ?? string.Empty;

                cfg.Providers.Infisical = ip;
            }
        }

        // Default provider order if empty: file -> env -> infisical -> azure-kv (your preference can differ)
        if (cfg.Providers.Order.Count == 0)
        {
            cfg.Providers.Order.AddRange(new[]
            {
                new SbConfig.ProvidersSection.OrderItem { Type = "file" },
                new SbConfig.ProvidersSection.OrderItem { Type = "env"  },
                new SbConfig.ProvidersSection.OrderItem { Type = "infisical" },
                new SbConfig.ProvidersSection.OrderItem { Type = "azure-kv" },
            });
        }

        return cfg;
    }
}