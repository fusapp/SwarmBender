using SwarmBender.Core.Abstractions;
using SwarmBender.Core.Data.Models;

namespace SwarmBender.Core.Pipeline;

/// <summary>Wires stages (Decorator/Pipeline). Order is important.</summary>
public sealed class RenderOrchestrator : IRenderOrchestrator
{
    private readonly IEnumerable<IRenderStage> _stages;

    public RenderOrchestrator(IEnumerable<IRenderStage> stages)
    {
        _stages = stages;
    }

    public async Task<RenderResult> RunAsync(RenderRequest request, CancellationToken ct = default)
    {
        var ctx = new RenderContext
        {
            RootPath = request.RootPath,
            StackId  = request.StackId,
            Env      = request.Env
        };

        // Reserved tokens
        ctx.Tokens["SB_STACK_ID"] = request.StackId;
        ctx.Tokens["SB_ENV"]      = request.Env;

        foreach (var stage in _stages)
            await stage.ExecuteAsync(ctx, ct);

        // Determine output location (SerializeStage should write & store path into token or ctx; here we keep simple)
        var outFile = Path.Combine(request.RootPath, request.OutDir, $"{request.StackId}-{request.Env}.stack.yml");
        return new RenderResult(Yaml: "", OutFile: outFile); // actual YAML already written by SerializeStage (MVP)
    }
}