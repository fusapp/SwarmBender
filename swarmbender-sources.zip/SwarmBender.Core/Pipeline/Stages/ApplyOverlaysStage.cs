using SwarmBender.Core.Abstractions;
using SwarmBender.Core.Data.Models;
using SwarmBender.Core.Util;

namespace SwarmBender.Core.Pipeline.Stages;

/// <summary>Applies environment overlays in configured order (last-wins).</summary>
public sealed class ApplyOverlaysStage : IRenderStage
{
    private readonly IFileSystem _fs;
    private readonly IYamlEngine _yaml;
    private readonly SbConfig _cfg;

    public ApplyOverlaysStage(IFileSystem fs, IYamlEngine yaml, SbConfig cfg)
    {
        _fs = fs; _yaml = yaml; _cfg = cfg;
    }

    public Task ExecuteAsync(RenderContext ctx, CancellationToken ct)
    {
        foreach (var pat in _cfg.Render.OverlayOrder)
        {
            var resolved = pat.Replace("{env}", ctx.Env, StringComparison.Ordinal)
                .Replace("{stackId}", ctx.StackId, StringComparison.Ordinal);
            foreach (var file in _fs.GlobFiles(ctx.RootPath, resolved))
            {
                var text = System.IO.File.ReadAllText(file);
                var overlay = _yaml.LoadToMap(text);
                DeepMerge.Merge(ctx.Compose, overlay);
            }
        }
        return Task.CompletedTask;
    }
}