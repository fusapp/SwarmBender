using System.Text.Json;
using SwarmBender.Core.Abstractions;
using SwarmBender.Core.Data.Models;
using SwarmBender.Core.Util;

namespace SwarmBender.Core.Pipeline.Stages;

/// <summary>
/// Collects JSON env from:
///  - stacks/all/{env}/env/*.json
///  - stacks/{stackId}/{env}/env/*.json
/// Flattens keys and splits into EnvVars vs SecretCandidates by secretize patterns.
/// </summary>
public sealed class EnvJsonCollectStage : IRenderStage
{
    private readonly IFileSystem _fs;
    private readonly SbConfig _cfg;

    public EnvJsonCollectStage(IFileSystem fs, SbConfig cfg)
    {
        _fs = fs; _cfg = cfg;
    }

    public async Task ExecuteAsync(RenderContext ctx, CancellationToken ct)
    {
        var roots = new[]
        {
            Path.Combine(ctx.RootPath, "stacks", "all", ctx.Env, "env"),
            Path.Combine(ctx.RootPath, "stacks", ctx.StackId, ctx.Env, "env")
        };

        foreach (var dir in roots)
        {
            if (!Directory.Exists(dir)) continue;

            var files = Directory.EnumerateFiles(dir, "*.json", SearchOption.TopDirectoryOnly)
                .OrderBy(p => p, System.StringComparer.OrdinalIgnoreCase);
            foreach (var f in files)
            {
                await using var s = File.OpenRead(f);
                var doc = await JsonDocument.ParseAsync(s, cancellationToken: ct);
                var flat = JsonFlatten.Flatten(doc.RootElement);

                foreach (var (k, v) in flat)
                {
                    if (SecretMatch.IsSecret(k, _cfg.Secretize.Paths))
                    {
                        // Save as candidate for secret engine; do NOT expose to EnvVars
                        ctx.SecretCandidates[k] = v;
                    }
                    else
                    {
                        ctx.EnvVars[k] = v; // last file wins
                    }
                }
            }
        }
    }
}