using SwarmBender.Core.Abstractions;
using SwarmBender.Core.Data.Models;

namespace SwarmBender.Core.Pipeline.Stages;

/// <summary>
/// Applies collected EnvVars to each service's environment (respect existing keys; collected last-wins).
/// SecretCandidates are never written here.
/// </summary>
public sealed class EnvironmentApplyStage : IRenderStage
{
    public Task ExecuteAsync(RenderContext ctx, CancellationToken ct)
    {
        if (!ctx.Compose.TryGetValue("services", out var svcNode) || svcNode is not IDictionary<string, object?> services)
            return Task.CompletedTask;

        foreach (var (svcName, node) in services.ToList())
        {
            if (node is not IDictionary<string, object?> svcMap) continue;

            // Read existing env (list or map) to a dictionary
            var existing = ReadEnvAsDict(svcMap.TryGetValue("environment", out var envNode) ? envNode : null);

            // Merge collected EnvVars (last-wins)
            foreach (var (k, v) in ctx.EnvVars)
                existing[k] = v;

            // Write back as sequence "KEY=VALUE"
            svcMap["environment"] = existing.Select(kv => $"{kv.Key}={kv.Value}").ToList();
        }

        return Task.CompletedTask;
    }

    private static IDictionary<string, string> ReadEnvAsDict(object? envNode)
    {
        var dict = new Dictionary<string, string>(System.StringComparer.OrdinalIgnoreCase);

        switch (envNode)
        {
            case null:
                break;

            case IDictionary<string, object?> m:
                foreach (var kv in m)
                    dict[kv.Key] = kv.Value?.ToString() ?? string.Empty;
                break;

            case IEnumerable<object?> seq:
                foreach (var item in seq)
                {
                    var s = item?.ToString() ?? "";
                    var idx = s.IndexOf('=');
                    if (idx > 0)
                    {
                        var k = s[..idx];
                        var v = s[(idx + 1)..];
                        dict[k] = v;
                    }
                }
                break;
        }
        return dict;
    }
}