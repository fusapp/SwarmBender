using SwarmBender.Core.Abstractions;
using SwarmBender.Core.Data.Models;

namespace SwarmBender.Core.Pipeline.Stages;

/// <summary>
/// Normalizes labels (service-level and deploy-level) and enforces precedence rules:
/// - Template labels override overlay labels for the same key.
/// - Keep service-level and deploy-level label buckets separate.
/// - Remove duplicate keys; keep the chosen value once.
/// - Preserve a stable order: template keys first (original order), then any additional keys.
/// Requires RenderContext to provide both Template and Working compose documents.
/// </summary>
public sealed class LabelsStage : IRenderStage
{
    public Task ExecuteAsync(RenderContext ctx, CancellationToken ct)
    {
        // Both documents must exist; if not, just normalize/dedupe on working doc.
        var template = ctx.Template ?? ctx.Working;
        var working  = ctx.Working;

        var tServices = GetServices(template);
        var wServices = GetServices(working);

        foreach (var (svcName, wSvc) in wServices)
        {
            ct.ThrowIfCancellationRequested();

            tServices.TryGetValue(svcName, out var tSvc);

            // --- service-level labels ---
            var (tSvcDict, tSvcOrder) = ExtractLabelDictAndOrder(GetNode(tSvc, "labels"));
            var (wSvcDict, _)         = ExtractLabelDictAndOrder(GetNode(wSvc, "labels"));

            var mergedSvc = MergeWithTemplatePrecedence(tSvcDict, tSvcOrder, wSvcDict);
            if (mergedSvc.Count > 0)
                SetLabelsSequence(wSvc, "labels", mergedSvc, tSvcOrder);
            else
                RemoveKey(wSvc, "labels");

            // --- deploy-level labels ---
            var tDep = GetMap(GetNode(tSvc, "deploy"));
            var wDep = EnsureMap(wSvc, "deploy");
            var (tDepDict, tDepOrder) = ExtractLabelDictAndOrder(GetNode(tDep, "labels"));
            var (wDepDict, _)         = ExtractLabelDictAndOrder(GetNode(wDep, "labels"));

            var mergedDep = MergeWithTemplatePrecedence(tDepDict, tDepOrder, wDepDict);
            if (mergedDep.Count > 0)
                SetLabelsSequence(wDep, "labels", mergedDep, tDepOrder);
            else
                RemoveKey(wDep, "labels");
        }

        return Task.CompletedTask;
    }

    // ----------------- helpers -----------------

    private static IDictionary<string, object?> EnsureMap(IDictionary<string, object?> parent, string key)
    {
        if (!parent.TryGetValue(key, out var node) || node is not IDictionary<string, object?> map)
        {
            map = new Dictionary<string, object?>(StringComparer.OrdinalIgnoreCase);
            parent[key] = map;
        }
        return map;
    }

    private static void RemoveKey(IDictionary<string, object?> map, string key)
    {
        if (map.ContainsKey(key)) map.Remove(key);
    }

    private static object? GetNode(IDictionary<string, object?>? map, string key)
    {
        if (map is null) return null;
        return map.TryGetValue(key, out var v) ? v : null;
    }

    private static IDictionary<string, object?>? GetMap(object? node)
        => node as IDictionary<string, object?>;

    private static Dictionary<string, IDictionary<string, object?>> GetServices(IDictionary<string, object?> root)
    {
        var result = new Dictionary<string, IDictionary<string, object?>>(StringComparer.OrdinalIgnoreCase);
        if (!root.TryGetValue("services", out var node) || node is not IDictionary<string, object?> map)
            return result;

        foreach (var kv in map)
            if (kv.Value is IDictionary<string, object?> svc)
                result[kv.Key] = svc;

        return result;
    }

    private static (Dictionary<string, string> dict, List<string> order) ExtractLabelDictAndOrder(object? labelsNode)
    {
        var dict  = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        var order = new List<string>();

        if (labelsNode is IEnumerable<object?> seq)
        {
            foreach (var it in seq)
            {
                var s = it?.ToString();
                if (string.IsNullOrWhiteSpace(s)) continue;
                var (k, v) = SplitKv(s);
                if (!dict.ContainsKey(k))
                {
                    dict[k] = v;
                    order.Add(k);
                }
                else
                {
                    // keep existing (first from template), later duplicates ignored here;
                    // overlay merge happens separately via MergeWithTemplatePrecedence.
                }
            }
        }
        else if (labelsNode is IDictionary<string, object?> m)
        {
            // mapping form; convert to k=v
            foreach (var kv in m)
            {
                var v = kv.Value?.ToString() ?? "";
                if (!dict.ContainsKey(kv.Key))
                {
                    dict[kv.Key] = v;
                    order.Add(kv.Key);
                }
            }
        }

        return (dict, order);
    }

    private static Dictionary<string, string> MergeWithTemplatePrecedence(
        Dictionary<string, string> template, List<string> templateOrder,
        Dictionary<string, string> working)
    {
        // Start with template values
        var result = new Dictionary<string, string>(template, StringComparer.OrdinalIgnoreCase);

        // Add keys that are not in template or have no conflict
        foreach (var (k, v) in working)
        {
            if (!result.ContainsKey(k))
                result[k] = v;
            // If exists in template, template wins (do nothing).
        }

        return result;
    }

    private static void SetLabelsSequence(
        IDictionary<string, object?> owner, string key,
        Dictionary<string, string> dict, List<string> templateOrder)
    {
        var seq = new List<object?>();

        // Template order first
        foreach (var k in templateOrder)
            if (dict.TryGetValue(k, out var v))
                seq.Add($"{k}={v}");

        // Then any extra keys (stable order by name)
        foreach (var k in dict.Keys.OrderBy(x => x, StringComparer.OrdinalIgnoreCase))
            if (!templateOrder.Contains(k, StringComparer.OrdinalIgnoreCase))
                seq.Add($"{k}={dict[k]}");

        owner[key] = seq;
    }

    private static (string key, string value) SplitKv(string s)
    {
        var idx = s.IndexOf('=');
        if (idx < 0) return (s.Trim(), "");
        return (s.Substring(0, idx).Trim(), s.Substring(idx + 1).Trim());
    }
}