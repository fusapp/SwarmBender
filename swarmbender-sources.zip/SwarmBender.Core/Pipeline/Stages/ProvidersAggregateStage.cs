using System.Text.Json;
using SwarmBender.Core.Abstractions;
using SwarmBender.Core.Data.Models;
using SwarmBender.Core.Providers.Azure;
using SwarmBender.Core.Providers.Infisical;
using SwarmBender.Core.Util;

namespace SwarmBender.Core.Pipeline.Stages;

/// <summary>
/// Aggregates from configured providers in order (last-wins).
/// MVP: file + env implemented. azure-kv/infisical: placeholders for next step.
/// </summary>
public sealed class ProvidersAggregateStage : IRenderStage
{
    private readonly IFileSystem _fs;
    private readonly SbConfig _cfg;
    
    private readonly IAzureKvCollector _akv;
    private readonly IInfisicalCollector _inf;

    public ProvidersAggregateStage(IFileSystem fs, SbConfig cfg, IAzureKvCollector akv, IInfisicalCollector inf)
    {
        _fs = fs; _cfg = cfg;
        _akv = akv;
        _inf = inf;
    }

    public async Task ExecuteAsync(RenderContext ctx, CancellationToken ct)
    {
        foreach (var item in _cfg.Providers.Order)
        {
            switch (item.Type.ToLowerInvariant())
            {
                case "file":
                    await CollectFromFileAsync(ctx, ct);
                    break;

                case "env":
                    CollectFromProcessEnv(ctx);
                    break;

                case "azure-kv":
                {
                    var kv = await _akv.CollectAsync(_cfg.Providers.AzureKv, ctx.StackId, ctx.Env, ct);
                    foreach (var (k, v) in kv)
                    {
                        if (Util.SecretMatch.IsSecret(k, _cfg.Secretize.Paths))
                            ctx.SecretCandidates[k] = v;
                        else
                            ctx.EnvVars[k] = v;
                    }
                    break;
                }

                case "infisical":
                {
                    var kv = await _inf.CollectAsync(_cfg.Providers.Infisical, ctx.StackId, ctx.Env, ct);
                    foreach (var (k, v) in kv)
                    {
                        if (Util.SecretMatch.IsSecret(k, _cfg.Secretize.Paths))
                            ctx.SecretCandidates[k] = v;
                        else
                            ctx.EnvVars[k] = v;
                    }
                    break;
                }

                default:
                    ctx.Warnings.Add($"Unknown provider type '{item.Type}'. Skipped.");
                    break;
            }
        }
    }

    private async Task CollectFromFileAsync(RenderContext ctx, CancellationToken ct)
    {
        var dirs = _cfg.Providers.File.ExtraJsonDirs
            .Select(p => p.Replace("{stackId}", ctx.StackId, StringComparison.Ordinal)
                          .Replace("{env}", ctx.Env, StringComparison.Ordinal))
            .Select(p => Path.IsPathRooted(p) ? p : Path.Combine(ctx.RootPath, p))
            .ToArray();

        foreach (var dir in dirs)
        {
            if (!Directory.Exists(dir)) continue;

            var files = Directory.EnumerateFiles(dir, "*.json", SearchOption.TopDirectoryOnly)
                                 .OrderBy(p => p, System.StringComparer.OrdinalIgnoreCase);
            foreach (var f in files)
            {
                await using var s = File.OpenRead(f);
                var doc = await JsonDocument.ParseAsync(s, cancellationToken: ct);
                var flat = JsonFlatten.Flatten(doc.RootElement);

                foreach (var (k, v) in flat)
                {
                    if (SecretMatch.IsSecret(k, _cfg.Secretize.Paths))
                        ctx.SecretCandidates[k] = v;
                    else
                        ctx.EnvVars[k] = v; // provider order ⇒ last wins
                }
            }
        }
    }

    private void CollectFromProcessEnv(RenderContext ctx)
    {
        // Load allowlist file paths and merge env vars filtered by allowlist keys
        foreach (var pathTpl in _cfg.Providers.Env.AllowlistFileSearch)
        {
            var path = pathTpl.Replace("{stackId}", ctx.StackId, StringComparison.Ordinal)
                              .Replace("{env}", ctx.Env, StringComparison.Ordinal);
            path = Path.IsPathRooted(path) ? path : Path.Combine(ctx.RootPath, path);
            if (!File.Exists(path)) continue;

            string[] allow;
            try
            {
                var json = System.IO.File.ReadAllText(path);
                var doc = System.Text.Json.JsonDocument.Parse(json);
                if (doc.RootElement.ValueKind == System.Text.Json.JsonValueKind.Array)
                {
                    allow = doc.RootElement.EnumerateArray()
                        .Select(e => e.GetString() ?? string.Empty)
                        .Where(s => !string.IsNullOrWhiteSpace(s))
                        .ToArray();
                }
                else
                {
                    continue;
                }
            }
            catch
            {
                continue;
            }

            var proc = Environment.GetEnvironmentVariables();
            foreach (var keyObj in proc.Keys)
            {
                var key = keyObj?.ToString() ?? "";
                if (string.IsNullOrWhiteSpace(key)) continue;
                if (!allow.Contains(key, StringComparer.OrdinalIgnoreCase)) continue;

                var val = proc[keyObj]?.ToString() ?? string.Empty;

                if (SecretMatch.IsSecret(key, _cfg.Secretize.Paths))
                    ctx.SecretCandidates[key] = val;
                else
                    ctx.EnvVars[key] = val;
            }
        }
    }
}