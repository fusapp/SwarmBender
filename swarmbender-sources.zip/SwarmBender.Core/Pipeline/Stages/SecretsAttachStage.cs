using SwarmBender.Core.Abstractions;
using SwarmBender.Core.Data.Models;

namespace SwarmBender.Core.Pipeline.Stages;

/// <summary>
/// Attaches docker secrets to services based on x-sb-secrets entries and secrets-map file.
/// Also removes secretized variables from service environment.
/// - Reads ops/vars/secrets-map.{env}.yml (key -> secretName)
/// - Supports entries:
///     - "ConnectionStrings__MSSQL_Master"
///     - { key: "Redis__Master", target: "/run/secrets/redis", mode: "0444", uid: "0", gid: "0" }
/// - Ensures root-level secrets: { name: { external: true } }
/// </summary>
public sealed class SecretsAttachStage : IRenderStage
{
    private readonly IYamlEngine _yaml;
    private readonly SbConfig _cfg;
    private readonly IFileSystem _fs;

    public SecretsAttachStage(IYamlEngine yaml, SbConfig cfg, IFileSystem fs)
    {
        _yaml = yaml; _cfg = cfg; _fs = fs;
    }

    public async Task ExecuteAsync(RenderContext ctx, CancellationToken ct)
    {
        var mapPath = Path.Combine(ctx.RootPath, "ops", "vars", $"secrets-map.{ctx.Env}.yml");
        var secretsMap = await LoadSecretsMapAsync(mapPath, ct);

        var rootSecrets = EnsureRootSecrets(ctx.Working);

        foreach (var (svcName, svc) in GetServices(ctx.Working))
        {
            ct.ThrowIfCancellationRequested();

            var sbList = GetSbSecretsList(svc);
            if (sbList.Count == 0)
                continue;

            // Compose 'secrets' list for this service
            var svcSecrets = EnsureServiceSecrets(svc);

            foreach (var item in sbList)
            {
                var (key, opts) = ExtractKeyAndOpts(item);
                if (string.IsNullOrWhiteSpace(key)) { ctx.Warnings.Add($"x-sb-secrets item missing 'key' (svc={svcName})."); continue; }

                // Map flattened key -> docker secret name
                if (!secretsMap.TryGetValue(key, out var secretName) || string.IsNullOrWhiteSpace(secretName))
                {
                    ctx.Warnings.Add($"No secrets-map entry for key '{key}' (env '{ctx.Env}', service '{svcName}').");
                    continue;
                }

                // service.secrets entry (long syntax)
                var entry = new Dictionary<string, object?>(StringComparer.OrdinalIgnoreCase)
                {
                    ["source"] = secretName
                };

                if (opts.TryGetValue("target", out var target) && target is string t && !string.IsNullOrWhiteSpace(t))
                    entry["target"] = t;
                if (opts.TryGetValue("mode", out var mode) && mode is string m && !string.IsNullOrWhiteSpace(m))
                    entry["mode"] = m;
                if (opts.TryGetValue("uid", out var uid) && uid is string u && !string.IsNullOrWhiteSpace(u))
                    entry["uid"] = u;
                if (opts.TryGetValue("gid", out var gid) && gid is string g && !string.IsNullOrWhiteSpace(g))
                    entry["gid"] = g;

                svcSecrets.Add(entry);

                // root.secrets definition
                if (!rootSecrets.ContainsKey(secretName))
                    rootSecrets[secretName] = new Dictionary<string, object?> { ["external"] = true };
            }

            // Remove secretized env vars from environment
            RemoveSecretizedEnvVars(svc);
        }
    }

    // -------------- helpers ----------------

    private async Task<Dictionary<string, string>> LoadSecretsMapAsync(string path, CancellationToken ct)
    {
        var dict = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        if (!_fs.FileExists(path)) return dict;

        var map = await _yaml.LoadYamlAsync(path, ct);
        foreach (var kv in map)
            if (!string.IsNullOrWhiteSpace(kv.Key) && kv.Value?.ToString() is { } s && !string.IsNullOrWhiteSpace(s))
                dict[kv.Key] = s;

        return dict;
    }

    private static IDictionary<string, object?> EnsureRootSecrets(IDictionary<string, object?> root)
    {
        if (!root.TryGetValue("secrets", out var node) || node is not IDictionary<string, object?> map)
        {
            map = new Dictionary<string, object?>(StringComparer.OrdinalIgnoreCase);
            root["secrets"] = map;
        }
        return map;
    }

    private static Dictionary<string, IDictionary<string, object?>> GetServices(IDictionary<string, object?> root)
    {
        var result = new Dictionary<string, IDictionary<string, object?>>(StringComparer.OrdinalIgnoreCase);
        if (!root.TryGetValue("services", out var node) || node is not IDictionary<string, object?> map)
            return result;

        foreach (var kv in map)
            if (kv.Value is IDictionary<string, object?> svc)
                result[kv.Key] = svc;

        return result;
    }

    private static List<object?> GetSbSecretsList(IDictionary<string, object?> svc)
    {
        if (!svc.TryGetValue("x-sb-secrets", out var node) || node is not IEnumerable<object?> seq)
            return new List<object?>(0);

        return new List<object?>(seq);
    }

    private static List<object?> EnsureServiceSecrets(IDictionary<string, object?> svc)
    {
        if (!svc.TryGetValue("secrets", out var node) || node is not IEnumerable<object?> seq)
        {
            var list = new List<object?>();
            svc["secrets"] = list;
            return list;
        }
        else
        {
            return (node as List<object?>) ?? new List<object?>(seq);
        }
    }

    private static (string key, IDictionary<string, object?> opts) ExtractKeyAndOpts(object? item)
    {
        if (item is string s && !string.IsNullOrWhiteSpace(s))
            return (s, new Dictionary<string, object?>());

        if (item is IDictionary<string, object?> m)
        {
            string key = "";
            if (m.TryGetValue("key", out var k) && k?.ToString() is { } ks) key = ks;
            return (key, m);
        }

        return ("", new Dictionary<string, object?>());
    }

    private void RemoveSecretizedEnvVars(IDictionary<string, object?> svc)
    {
        if (!svc.TryGetValue("environment", out var node) || node is not IEnumerable<object?> envSeq)
            return;

        var keep = new List<object?>();
        foreach (var item in envSeq)
        {
            var s = item?.ToString();
            if (string.IsNullOrWhiteSpace(s)) continue;

            var eq = s.IndexOf('=');
            var key = eq >= 0 ? s.Substring(0, eq) : s;

            if (!Util.SecretMatch.IsSecret(key, _cfg.Secretize.Paths))
                keep.Add(item);
        }

        svc["environment"] = keep;
    }
}