using SwarmBender.Core.Abstractions;
using SwarmBender.Core.Data.Models;

namespace SwarmBender.Core.Pipeline.Stages;


/// <summary>Serializes final compose map to YAML.</summary>
public sealed class SerializeStage : IRenderStage
{
    private readonly IFileSystem _fs;
    private readonly IYamlEngine _yaml;

    public SerializeStage(IFileSystem fs, IYamlEngine yaml)
    {
        _fs = fs; _yaml = yaml;
    }

    public async Task ExecuteAsync(RenderContext ctx, CancellationToken ct)
    {
        var yaml = _yaml.DumpFromMap(ctx.Compose);
        var outDir = Path.Combine(ctx.RootPath, "ops", "state", "last");
        _fs.EnsureDirectory(outDir);
        var outFile = Path.Combine(outDir, $"{ctx.StackId}-{ctx.Env}.stack.yml");
        await _fs.WriteAllTextAsync(outFile, yaml, ct);
    }
}