using SwarmBender.Core.Abstractions;
using SwarmBender.Core.Data.Models;

namespace SwarmBender.Core.Pipeline.Stages;

/// <summary>Loads stacks/{stackId}/docker-stack.template.yml into context.Compose.</summary>
public sealed class TemplateLoaderStage : IRenderStage
{
    private readonly IFileSystem _fs;
    private readonly IYamlEngine _yaml;

    public TemplateLoaderStage(IFileSystem fs, IYamlEngine yaml)
    {
        _fs = fs; _yaml = yaml;
    }

    public async Task ExecuteAsync(RenderContext ctx, CancellationToken ct)
    {
        var path = Path.Combine(ctx.RootPath, "stacks", ctx.StackId, "docker-stack.template.yml");
        if (!_fs.FileExists(path))
            throw new FileNotFoundException($"Template not found: {path}");

        var text = await _fs.ReadAllTextAsync(path, ct);
        var map  = _yaml.LoadToMap(text);
        foreach (var kv in map) ctx.Compose[kv.Key] = kv.Value;
    }
}