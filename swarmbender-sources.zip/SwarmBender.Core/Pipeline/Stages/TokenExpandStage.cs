using System.Collections;
using System.Text.RegularExpressions;
using SwarmBender.Core.Abstractions;
using SwarmBender.Core.Data.Models;

namespace SwarmBender.Core.Pipeline.Stages;

/// <summary>
/// Expands ${VAR} tokens across all string values in the working document.
/// Sources: service environment (already merged), process env (allowlist uygulanmışsa önceki stage’lerde),
/// and reserved tokens: SB_STACK_ID, SB_ENV, SB_SERVICE_NAME.
/// </summary>
public sealed class TokenExpandStage : IRenderStage
{
    private static readonly Regex TokenRe = new(@"\$\{([A-Za-z0-9_\-\.]+)\}", RegexOptions.Compiled);

    public Task ExecuteAsync(RenderContext ctx, CancellationToken ct)
    {
        var services = GetServices(ctx.Working);

        foreach (var (svcName, svc) in services)
        {
            ct.ThrowIfCancellationRequested();

            // Build token table for this service
            var tokens = BuildTokenTable(ctx, svcName, svc);

            // Walk the service map and expand
            ExpandMapInPlace(svc, tokens);
        }

        return Task.CompletedTask;
    }

    private static Dictionary<string, string> BuildTokenTable(RenderContext ctx, string serviceName, IDictionary<string, object?> svc)
    {
        var tokens = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        // From service environment
        if (svc.TryGetValue("environment", out var envNode) && envNode is IEnumerable envSeq)
        {
            foreach (var it in envSeq)
            {
                var s = it?.ToString();
                if (string.IsNullOrWhiteSpace(s)) continue;
                var idx = s.IndexOf('=');
                var k = idx >= 0 ? s.Substring(0, idx) : s;
                var v = idx >= 0 ? s.Substring(idx + 1) : "";
                if (!tokens.ContainsKey(k)) tokens[k] = v ?? "";
            }
        }

        // Process env as fallback (do not override existing)
        foreach (DictionaryEntry de in Environment.GetEnvironmentVariables())
        {
            var k = de.Key?.ToString();
            var v = de.Value?.ToString() ?? "";
            if (string.IsNullOrWhiteSpace(k)) continue;
            if (!tokens.ContainsKey(k)) tokens[k] = v;
        }

        // Reserved
        tokens["SB_STACK_ID"] = ctx.StackId;
        tokens["SB_ENV"] = ctx.Env;
        tokens["SB_SERVICE_NAME"] = serviceName;

        return tokens;
    }

    private static void ExpandMapInPlace(IDictionary<string, object?> map, IDictionary<string, string> tokens)
    {
        var keys = new List<string>(map.Keys);
        foreach (var k in keys)
        {
            var v = map[k];
            map[k] = ExpandAny(v, tokens);
        }
    }

    private static object? ExpandAny(object? node, IDictionary<string, string> tokens)
    {
        switch (node)
        {
            case null:
                return null;

            case string s:
                return ExpandString(s, tokens);

            case IDictionary<string, object?> m:
                {
                    var copy = new Dictionary<string, object?>(StringComparer.OrdinalIgnoreCase);
                    foreach (var kv in m)
                        copy[kv.Key] = ExpandAny(kv.Value, tokens);
                    return copy;
                }

            case IEnumerable<object?> seq:
                {
                    var list = new List<object?>();
                    foreach (var it in seq)
                        list.Add(ExpandAny(it, tokens));
                    return list;
                }

            default:
                return node;
        }
    }

    private static string ExpandString(string s, IDictionary<string, string> tokens)
    {
        return TokenRe.Replace(s, m =>
        {
            var name = m.Groups[1].Value;
            return tokens.TryGetValue(name, out var v) ? v : m.Value; // leave unknown as-is
        });
    }

    private static Dictionary<string, IDictionary<string, object?>> GetServices(IDictionary<string, object?> root)
    {
        var result = new Dictionary<string, IDictionary<string, object?>>(StringComparer.OrdinalIgnoreCase);
        if (!root.TryGetValue("services", out var node) || node is not IDictionary<string, object?> map)
            return result;

        foreach (var kv in map)
            if (kv.Value is IDictionary<string, object?> svc)
                result[kv.Key] = svc;

        return result;
    }
}