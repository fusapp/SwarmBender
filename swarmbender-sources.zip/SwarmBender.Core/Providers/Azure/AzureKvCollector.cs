using Azure;
using Azure.Core;
using Azure.Identity;
using Azure.Security.KeyVault.Secrets;
using SwarmBender.Core.Data.Models;

namespace SwarmBender.Core.Providers.Azure;

public sealed class AzureKvCollector : IAzureKvCollector
{
    public async Task<IDictionary<string, string>> CollectAsync(
        SbConfig.ProvidersSection.AzureKvProvider cfg,
        string stackId,
        string env,
        CancellationToken ct)
    {
        var bag = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        if (string.IsNullOrWhiteSpace(cfg.VaultUri))
            return bag;

        var cred = BuildCredential(cfg);
        var client = new SecretClient(new Uri(cfg.VaultUri!), cred);

        // Optional prefix filtering:
        var envMapped = cfg.EnvMap.TryGetValue(env, out var e) && !string.IsNullOrWhiteSpace(e) ? e : env;
        var prefix = cfg.KeyPrefix?.Replace("{env}", envMapped, StringComparison.Ordinal)
                                   .Replace("{stackId}", stackId, StringComparison.Ordinal);

        await foreach (var prop in client.GetPropertiesOfSecretsAsync(ct))
        {
            ct.ThrowIfCancellationRequested();

            if (!string.IsNullOrEmpty(prefix) && !prop.Name.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
                continue;

            try
            {
                KeyVaultSecret s = await client.GetSecretAsync(prop.Name, cancellationToken: ct);
                var flatKey = ToFlattenKey(prop.Name, prefix);
                bag[flatKey] = s.Value ?? string.Empty;
            }
            catch (RequestFailedException)
            {
                // skip individual failures
            }
        }

        return bag;
    }

    private static TokenCredential BuildCredential(SbConfig.ProvidersSection.AzureKvProvider cfg)
    {
        if (cfg.UseDefaultCredential)
            return new DefaultAzureCredential();

        if (!string.IsNullOrWhiteSpace(cfg.TenantId) &&
            !string.IsNullOrWhiteSpace(cfg.ClientId) &&
            !string.IsNullOrWhiteSpace(cfg.ClientSecret))
        {
            return new ClientSecretCredential(cfg.TenantId, cfg.ClientId, cfg.ClientSecret);
        }

        // Fallback to default if incomplete
        return new DefaultAzureCredential();
    }

    private static string ToFlattenKey(string secretName, string? prefix)
    {
        // Remove prefix segment if present (a/b/c -> a__b__c convention)
        var name = !string.IsNullOrEmpty(prefix) && secretName.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)
            ? secretName.Substring(prefix!.Length)
            : secretName;

        name = name.Trim('/');

        return name.Replace("/", "__"); // KV hierarchical naming => flattened
    }
}