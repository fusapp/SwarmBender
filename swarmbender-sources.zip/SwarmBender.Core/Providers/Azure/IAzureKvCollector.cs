using SwarmBender.Core.Data.Models;

namespace SwarmBender.Core.Providers.Azure;


/// <summary>
/// Reads secrets from Azure Key Vault using the official SDK.
/// </summary>
public interface IAzureKvCollector
{
    Task<IDictionary<string, string>> CollectAsync(
        SbConfig.ProvidersSection.AzureKvProvider cfg,
        string stackId,
        string env,
        CancellationToken ct);
}