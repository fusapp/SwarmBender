using SwarmBender.Core.Data.Models;

namespace SwarmBender.Core.Providers.Infisical;

public sealed class InfisicalCollector : IInfisicalCollector
{
    public async Task<IDictionary<string, string>> CollectAsync(
        SbConfig.ProvidersSection.InfisicalProvider cfg,
        string stackId,
        string env,
        CancellationToken ct)
    {
        var bag = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        var token = Environment.GetEnvironmentVariable(cfg.TokenEnvVar);
        if (string.IsNullOrWhiteSpace(token))
            return bag;

        var envSlug = cfg.EnvMap.TryGetValue(env, out var mapped) && !string.IsNullOrWhiteSpace(mapped)
            ? mapped : env;

        var secretPath = (cfg.PathTemplate ?? "/")
            .Replace("{stackId}", stackId, StringComparison.Ordinal)
            .Replace("{env}", envSlug, StringComparison.Ordinal);

        // Instantiate SDK client
        var client = new InfisicalClient(new InfisicalOptions
        {
            BaseUrl = cfg.BaseUrl,
            Token = token
        });

        // Fetch as plaintext KV
        var entries = await client.Secrets.ListAsync(new ListSecretsRequest
        {
            Environment = envSlug,
            ProjectIdOrSlug = cfg.ProjectId ?? cfg.ProjectSlug ?? "",
            Path = secretPath
        }, ct);

        foreach (var e in entries ?? Enumerable.Empty<SecretItem>())
        {
            var flatKey = MapKey(cfg, e.Key);
            var value   = e.Value ?? string.Empty;

            if (!string.IsNullOrWhiteSpace(flatKey))
                bag[flatKey] = value;
        }

        return bag;
    }

    private static string MapKey(SbConfig.ProvidersSection.InfisicalProvider cfg, string key)
    {
        var k = key ?? "";

        if (!string.IsNullOrEmpty(cfg.StripPrefix) && k.StartsWith(cfg.StripPrefix, StringComparison.Ordinal))
            k = k.Substring(cfg.StripPrefix.Length);

        foreach (var rp in cfg.Replace)
            k = k.Replace(rp.Key, rp.Value, StringComparison.Ordinal);

        // Use Docker-style flatten by default (replace ":" "/" "." with "__" if present)
        k = k.Replace(":", "__", StringComparison.Ordinal)
             .Replace("/", "__", StringComparison.Ordinal)
             .Replace(".", "__", StringComparison.Ordinal);

        var tpl = string.IsNullOrWhiteSpace(cfg.KeyTemplate) ? "{key}" : cfg.KeyTemplate;
        return tpl.Replace("{key}", k, StringComparison.Ordinal)
                  .Replace("{stackId}", "{stackId}", StringComparison.Ordinal); // left as-is for now
    }

    // --- Infisical SDK request/response stubs (adjust to real SDK) ---
    public sealed class InfisicalOptions
    {
        public string BaseUrl { get; init; } = "https://app.infisical.com";
        public string Token   { get; init; } = "";
    }

    public sealed class InfisicalClient
    {
        public InfisicalClient(InfisicalOptions o) { /* create http client etc. */ }
        public SecretsApi Secrets => new();

        public sealed class SecretsApi
        {
            public Task<IEnumerable<SecretItem>> ListAsync(ListSecretsRequest req, CancellationToken ct)
            {
                // NOTE: Replace with actual SDK call. Here we mimic shape.
                return Task.FromResult<IEnumerable<SecretItem>>(Array.Empty<SecretItem>());
            }
        }
    }

    public sealed class ListSecretsRequest
    {
        public string ProjectIdOrSlug { get; init; } = "";
        public string Environment     { get; init; } = "";
        public string Path            { get; init; } = "/";
    }

    public sealed class SecretItem
    {
        public string Key   { get; init; } = "";
        public string? Value { get; init; }
    }
}